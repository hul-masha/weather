from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'index/index.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    parent_template = None
    pass
    parent_template = environment.get_template('base.html', 'index/index.html')
    for name, parent_block in parent_template.blocks.items():
        context.blocks.setdefault(name, []).append(parent_block)
    yield from parent_template.root_render_func(context)

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield 'Weather page '

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_w = resolve('w')
    l_0_object_list = resolve('object_list')
    pass
    yield '\n<br><br>\n<br><br>\n\n    <article>\n        <br><br>\n          <p>Weather London</p>\n<br><br>\n<br><br>\n<br><br>\n        <big> <p align="center">\n           Weather London now: '
    yield to_string(environment.getitem((undefined(name='w') if l_0_w is missing else l_0_w), 0))
    yield ', '
    yield to_string(environment.getitem((undefined(name='w') if l_0_w is missing else l_0_w), 1))
    yield ', '
    yield to_string(environment.getitem((undefined(name='w') if l_0_w is missing else l_0_w), 2))
    yield ' </p>\n            <br><br>\n            '
    for l_1_p in (undefined(name='object_list') if l_0_object_list is missing else l_0_object_list):
        pass
        yield '\n              <p>'
        yield to_string(environment.getattr(l_1_p, 'city'))
        yield ', '
        yield to_string(environment.getattr(l_1_p, 'we'))
        yield ', '
        yield to_string(context.call(environment.getattr(environment.getattr(l_1_p, 'data'), 'strftime'), '%d-%m-%Y %H'))
        yield '</p>\n            '
    l_1_p = missing
    yield '\n      </big>\n    </article>\n<br><br>\n<br><br>\n<br><br>\n<br><br>\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '1=12&5=17&7=25&8=32&19=41&21=47&22=50'