from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'base.html'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_static = resolve('static')
    l_0_request = resolve('request')
    l_0_ns = missing
    pass
    yield '<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <title>'
    yield from context.blocks['title'][0](context)
    yield '</title>\n    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" type="text/css">\n\t<link rel="stylesheet" href="'
    yield to_string(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'css/font-awesome.min.css'))
    yield '" type="text/css">\n\t<link rel="stylesheet" href="'
    yield to_string(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'css/bootstrap.min.css'))
    yield '" type="text/css">\n    <link rel="stylesheet" href="'
    yield to_string(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'css/hero-slider-style.css'))
    yield '" type="text/css">\n    <link rel="stylesheet" href="'
    yield to_string(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'css/magnific-popup.css'))
    yield '" type="text/css">\n    <link rel="stylesheet" href="'
    yield to_string(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'css/tooplate-style.css'))
    yield '" type="text/css">\n    <link rel="shortcut icon" href="'
    yield to_string(context.call((undefined(name='static') if l_0_static is missing else l_0_static), 'favicon.ico'))
    yield '" type="image/x-icon">\n</head>\n\n<body>\n\n        <div class="cd-hero">\n            <div class="cd-slider-nav">\n                <nav class="navbar navbar-fixed-top">\n                    <div class="tm-navbar-bg">\n'
    l_0_ns = environment.getattr(environment.getattr((undefined(name='request') if l_0_request is missing else l_0_request), 'resolver_match'), 'namespace')
    context.vars['ns'] = l_0_ns
    context.exported_vars.add('ns')
    yield '\n\n    \n\n\n'
    yield from context.blocks['header'][0](context)
    yield '\n                    </div>\n                </nav>\n            </div>\n        </div>\n        '
    yield from context.blocks['main'][0](context)
    yield '\n\n</body>\n</html>'

def block_title(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_header(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass

def block_main(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    pass
    yield '\n'

blocks = {'title': block_title, 'header': block_header, 'main': block_main}
debug_info = '5=15&7=17&8=19&9=21&10=23&11=25&12=27&21=29&57=33&62=35&5=38&57=45&62=52'